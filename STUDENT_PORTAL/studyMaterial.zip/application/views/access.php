<div class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3"> 
    <section class="main-content-container container-fluid px-4">
      <h1>
        Access Denied
        <small>You are not authorize user to use this</small>
      </h1>
    </section>
    <section class="main-content-container container-fluid px-4">
            <div class="col-xs-12 text-center">
                <img src="<?php echo base_url() ?>assets/images/access.png" alt="Access Denied Image" />
            </div>
    </section>
</div>