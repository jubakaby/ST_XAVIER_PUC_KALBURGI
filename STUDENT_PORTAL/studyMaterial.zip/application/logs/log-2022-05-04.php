<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-04 00:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:00:30 --> Total execution time: 0.0716
DEBUG - 2022-05-04 00:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 00:00:31 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-04 00:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:00:33 --> Total execution time: 0.0467
DEBUG - 2022-05-04 00:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-04 00:00:45 --> Query error: Unknown column 'payment_year' in 'field list' - Invalid query: INSERT INTO `tbl_students_overall_fee_payment_info_2021` (`application_no`, `payment_type`, `payment_date`, `total_amount`, `paid_amount`, `excess_amount`, `fee_concession`, `payment_year`, `term_name`, `pending_balance`, `fee_pending_status`, `payment_count`, `order_id`, `collected_staff_name`, `created_by`, `created_date_time`) VALUES ('210868', 'ONLINE', '2022-05-04', '45000.00', '45000.00', 0, 0, '2022', 'II PUC', 0, 0, 1, '22S9862', 'schoolphins', '210868', '2022-05-04 00:00:45')
DEBUG - 2022-05-04 00:00:45 --> DB Transaction Failure
DEBUG - 2022-05-04 00:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-04 00:00:46 --> Query error: Unknown column 'payment_year' in 'field list' - Invalid query: INSERT INTO `tbl_students_overall_fee_payment_info_2021` (`application_no`, `payment_type`, `payment_date`, `total_amount`, `paid_amount`, `excess_amount`, `fee_concession`, `payment_year`, `term_name`, `pending_balance`, `fee_pending_status`, `payment_count`, `order_id`, `collected_staff_name`, `created_by`, `created_date_time`) VALUES ('210868', 'ONLINE', '2022-05-04', '45000.00', '45000.00', 0, 0, '2022', 'II PUC', 0, 0, 1, '22S9862', 'schoolphins', '210868', '2022-05-04 00:00:46')
DEBUG - 2022-05-04 00:00:46 --> DB Transaction Failure
DEBUG - 2022-05-04 00:00:46 --> Total execution time: 1.0610
DEBUG - 2022-05-04 00:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:00:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 00:00:46 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-04 00:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-04 00:01:34 --> Query error: Unknown column 'payment_year' in 'field list' - Invalid query: INSERT INTO `tbl_students_overall_fee_payment_info_2021` (`application_no`, `payment_type`, `payment_date`, `total_amount`, `paid_amount`, `excess_amount`, `fee_concession`, `payment_year`, `term_name`, `pending_balance`, `fee_pending_status`, `payment_count`, `order_id`, `collected_staff_name`, `created_by`, `created_date_time`) VALUES ('210868', 'ONLINE', '2022-05-04', '45000.00', '45000.00', 0, 0, '2022', 'II PUC', 0, 0, 1, '22S9862', 'schoolphins', '210868', '2022-05-04 00:01:34')
DEBUG - 2022-05-04 00:01:34 --> DB Transaction Failure
DEBUG - 2022-05-04 00:01:34 --> Total execution time: 0.6042
DEBUG - 2022-05-04 00:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:01:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 00:01:35 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-04 00:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:03:47 --> Total execution time: 0.0698
DEBUG - 2022-05-04 00:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:03:57 --> Total execution time: 0.0421
DEBUG - 2022-05-04 00:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:05:13 --> Total execution time: 2.8154
DEBUG - 2022-05-04 00:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:05:15 --> Total execution time: 0.0707
DEBUG - 2022-05-04 00:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 00:05:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-04 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:05:28 --> Total execution time: 0.0622
DEBUG - 2022-05-04 00:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:05:38 --> Total execution time: 0.4593
DEBUG - 2022-05-04 00:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 00:05:39 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-04 00:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:08:42 --> Total execution time: 1.2746
DEBUG - 2022-05-04 00:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 00:08:42 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-04 00:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:11:38 --> Total execution time: 1.8477
DEBUG - 2022-05-04 00:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 00:11:38 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-04 00:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-04 00:12:48 --> Query error: Unknown column 'fee.payment_year' in 'where clause' - Invalid query: SELECT *
FROM `tbl_admission_students_overall_fee_payment_info` as `fee`
WHERE `fee`.`is_deleted` =0
AND `fee`.`payment_year` = '2022'
AND `fee`.`application_no` = '210374'
ERROR - 2022-05-04 00:12:48 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\application\models\Admission_model.php 269
DEBUG - 2022-05-04 00:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:13:33 --> Total execution time: 2.5496
DEBUG - 2022-05-04 00:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 00:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 00:13:37 --> Total execution time: 0.6730
DEBUG - 2022-05-04 00:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 00:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 00:13:37 --> 404 Page Not Found: Assets/images
