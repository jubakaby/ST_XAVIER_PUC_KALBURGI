<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-03 00:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 00:27:43 --> No URI present. Default controller set.
DEBUG - 2022-05-03 00:27:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 00:27:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'sjpuc_schoolphins_v2' C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-05-03 00:27:43 --> Unable to connect to the database
DEBUG - 2022-05-03 00:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 00:27:43 --> Total execution time: 0.0606
DEBUG - 2022-05-03 14:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:43:42 --> No URI present. Default controller set.
DEBUG - 2022-05-03 14:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 14:43:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'sjpuc_schoolphins_v2' C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-05-03 14:43:42 --> Unable to connect to the database
DEBUG - 2022-05-03 14:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:43:42 --> Total execution time: 0.0532
DEBUG - 2022-05-03 14:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:47:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 14:47:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'sjpuc_schoolphins_v2' C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-05-03 14:47:30 --> Unable to connect to the database
DEBUG - 2022-05-03 14:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-03 14:47:30 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\system\database\drivers\mysqli\mysqli_driver.php 391
DEBUG - 2022-05-03 14:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-03 14:48:07 --> Severity: error --> Exception: Call to a member function prepare() on null C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\application\views\dashboard.php 481
DEBUG - 2022-05-03 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:48:32 --> Total execution time: 3.7932
DEBUG - 2022-05-03 14:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:49:42 --> Total execution time: 3.9042
DEBUG - 2022-05-03 14:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:49:44 --> Total execution time: 0.0540
DEBUG - 2022-05-03 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:49:51 --> Total execution time: 4.6331
DEBUG - 2022-05-03 14:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:50:00 --> Total execution time: 4.4849
DEBUG - 2022-05-03 14:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:50:13 --> Total execution time: 3.5440
DEBUG - 2022-05-03 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:50:26 --> Total execution time: 3.5836
DEBUG - 2022-05-03 14:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:50:43 --> Total execution time: 3.6140
DEBUG - 2022-05-03 14:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:50:47 --> Total execution time: 0.0607
DEBUG - 2022-05-03 14:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:52:48 --> Total execution time: 5.9935
DEBUG - 2022-05-03 14:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:53:50 --> Total execution time: 3.6987
DEBUG - 2022-05-03 14:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:54:18 --> Total execution time: 3.6352
DEBUG - 2022-05-03 14:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:54:21 --> Total execution time: 0.0827
DEBUG - 2022-05-03 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 14:54:21 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:56:38 --> Total execution time: 0.0663
DEBUG - 2022-05-03 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 14:56:38 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 14:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:57:58 --> Total execution time: 0.0923
DEBUG - 2022-05-03 14:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:57:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 14:57:59 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 14:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:59:59 --> Total execution time: 0.0537
DEBUG - 2022-05-03 15:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:00:09 --> Total execution time: 2.8706
DEBUG - 2022-05-03 15:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:00:12 --> Total execution time: 0.0751
DEBUG - 2022-05-03 15:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 15:00:12 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:03:07 --> Total execution time: 0.0694
DEBUG - 2022-05-03 15:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 15:03:08 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 15:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:03:24 --> Total execution time: 0.0418
DEBUG - 2022-05-03 15:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 15:03:25 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 15:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:03:32 --> Total execution time: 0.0460
DEBUG - 2022-05-03 15:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 15:03:32 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 15:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:03:38 --> Total execution time: 0.0687
DEBUG - 2022-05-03 15:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 15:03:38 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 15:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:03:50 --> Total execution time: 0.0503
DEBUG - 2022-05-03 15:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 15:03:51 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 15:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 15:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 15:04:15 --> Total execution time: 0.0459
DEBUG - 2022-05-03 15:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 15:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 15:04:15 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:21:37 --> Total execution time: 0.0554
DEBUG - 2022-05-03 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:22:51 --> Total execution time: 2.8249
DEBUG - 2022-05-03 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:22:59 --> Total execution time: 0.0455
DEBUG - 2022-05-03 23:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:23:13 --> Total execution time: 2.5587
DEBUG - 2022-05-03 23:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-03 23:23:17 --> Severity: Warning --> Use of undefined constant CURRENT_YEAR - assumed 'CURRENT_YEAR' (this will throw an Error in a future version of PHP) C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\application\views\admission\re_admission_2021.php 127
DEBUG - 2022-05-03 23:23:17 --> Total execution time: 0.0831
DEBUG - 2022-05-03 23:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:23:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:23:17 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-03 23:24:25 --> Severity: Warning --> Use of undefined constant CURRENT_YEAR - assumed 'CURRENT_YEAR' (this will throw an Error in a future version of PHP) C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\application\views\admission\re_admission_2021.php 127
DEBUG - 2022-05-03 23:24:25 --> Total execution time: 0.0619
DEBUG - 2022-05-03 23:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:24:26 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:24:56 --> Total execution time: 0.0640
DEBUG - 2022-05-03 23:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:24:56 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:25:49 --> Total execution time: 0.0785
DEBUG - 2022-05-03 23:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:25:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:25:49 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:28:03 --> Total execution time: 0.0553
DEBUG - 2022-05-03 23:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:28:04 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:28:41 --> Total execution time: 0.0564
DEBUG - 2022-05-03 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:28:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:28:42 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:29:09 --> Total execution time: 0.0605
DEBUG - 2022-05-03 23:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:29:10 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:32:00 --> Total execution time: 0.0824
DEBUG - 2022-05-03 23:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:32:01 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:34:53 --> Total execution time: 5.0835
DEBUG - 2022-05-03 23:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:35:07 --> Total execution time: 0.0575
DEBUG - 2022-05-03 23:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:35:08 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:36:12 --> Total execution time: 0.0710
DEBUG - 2022-05-03 23:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:36:13 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:36:29 --> Total execution time: 0.0509
DEBUG - 2022-05-03 23:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:36:29 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:37:44 --> Total execution time: 0.0601
DEBUG - 2022-05-03 23:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:37:45 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:38:24 --> Total execution time: 0.0557
DEBUG - 2022-05-03 23:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:38:25 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:39:26 --> Total execution time: 0.0562
DEBUG - 2022-05-03 23:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:39:27 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:40:39 --> Total execution time: 0.0637
DEBUG - 2022-05-03 23:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:40:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:40:39 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-03 23:41:50 --> Query error: Unknown column 'payment.year' in 'where clause' - Invalid query: SELECT *
FROM `tbl_student_fee_installment_info` as `payment`
WHERE `payment`.`application_no` = '210868'
AND `payment`.`payment_status` =0
AND `payment`.`year` = '2022'
AND `payment`.`is_deleted` =0
ERROR - 2022-05-03 23:41:50 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp_new\htdocs\SJPUC_BOYS_BANGALORE\STUDENT_PORTAL\application\models\Admission_model.php 497
DEBUG - 2022-05-03 23:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:42:28 --> Total execution time: 0.0593
DEBUG - 2022-05-03 23:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:42:28 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:43:07 --> Total execution time: 0.0668
DEBUG - 2022-05-03 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:43:08 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:43:23 --> Total execution time: 0.0974
DEBUG - 2022-05-03 23:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:43:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:43:23 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:44:58 --> Total execution time: 0.0491
DEBUG - 2022-05-03 23:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:44:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:44:59 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:46:35 --> Total execution time: 0.0600
DEBUG - 2022-05-03 23:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:46:35 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:46:36 --> Total execution time: 0.0520
DEBUG - 2022-05-03 23:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:46:49 --> Total execution time: 0.0782
DEBUG - 2022-05-03 23:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:46:49 --> 404 Page Not Found: Assets/images
DEBUG - 2022-05-03 23:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:47:01 --> Total execution time: 2.5676
DEBUG - 2022-05-03 23:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 23:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 23:47:05 --> Total execution time: 0.7577
DEBUG - 2022-05-03 23:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 23:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 23:47:06 --> 404 Page Not Found: Assets/images
